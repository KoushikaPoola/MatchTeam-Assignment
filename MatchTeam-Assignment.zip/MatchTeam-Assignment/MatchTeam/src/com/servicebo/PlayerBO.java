package com.servicebo;

import com.bean.Player;
import com.ui.*;


        public class PlayerBO {
	         Sports sport = new Sports();
	public Player createPlayer (String data) {
		 Player player = new Player();
		 String[] datas = data.split(",");
		 player.setName(datas[0]);
                 player.setSkill(datas[1]);
		 player.setCountry(datas[2]);
		
		return player;
	}

}
