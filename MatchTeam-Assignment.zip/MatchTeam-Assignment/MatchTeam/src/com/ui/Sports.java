package com.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.bean.*;
import com.servicebo.*;

public class Sports {

	public static void main(String[] args) {
		PlayerBO player = new PlayerBO();
		TeamBO team = new TeamBO();
		MatchBO match = new MatchBO();
		
		Player[] playerList = new Player[15];
		Team[] teamList = new Team[15];
		Match[] matchList = new Match[10];
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the players count:");
		int num = sc.nextInt();
		for(int j=1,t=0;j<=num;j++,t++) {
			
			System.out.println("Enter players "+ j + " details");
			String details = sc.next();
			playerList[t] = player.createPlayer(details);
			
		}
		
		
		
		System.out.println("Enter the team count:");
		int num1 = sc.nextInt();
		for(int j=1,t=0;j<=num1;j++,t++) {

			System.out.println("Enter team "+ j + " details");
			String details = sc.next();
			teamList[t] = team.createTeam(details, playerList);

		}
		
		System.out.println("Enter the match count:");
		int num2 = sc.nextInt();
		for(int j=1,t=0;j<=num2;j++,t++) {
			System.out.println("Enter match "+ j + " details");
			String details = sc.next();
			matchList[t] = match.createMatch(details, teamList);
		}
		while(true) {
		System.out.println("Menu:");
		System.out.println("1) Find Team \n" + "2) Find all matches in a specific venues");
		System.out.println("Enter your choice 1 or 2");
		
		int num3 = sc.nextInt();
		switch(num3) {
		case 1:
			System.out.println("Enter Match Date");
		        String matchdate = sc.next();
			match.findTeam(matchdate, matchList);
			break;
		case 2:
			System.out.println("Enter team name:");
                        break;
			
		default:
			System.out.println("Do you want to continue? Yes/No");
			String option = sc.next();
			if(option.equals("Yes")) {
				continue;
			}
			else {
				System.out.println("Exit");
				break;
			}
		}
	}
  }
}
